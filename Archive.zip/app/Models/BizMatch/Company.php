<?php

namespace App\Models\BizMatch;

use App\Models\User;
use App\Traits\ModelCanExtend;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use ToneflixCode\LaravelFileable\Traits\Fileable;

/**
 * @property \Illuminate\Database\Eloquent\Collection<Appointment> $appointments
 * @property \App\Models\User $user
 */
class Company extends Model
{
    /** @use HasFactory<\Database\Factories\BizMatch\CompanyFactory> */
    use HasFactory;
    use Fileable;
    use ModelCanExtend;

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'services' => \Illuminate\Database\Eloquent\Casts\AsCollection::class,
        ];
    }

    public function registerFileable()
    {
        $this->fileableLoader(
            file_field: ['image' => 'logo'],
            applyDefault: true,
        );
    }

    public static function registerEvents()
    {
        static::creating(function (self $model) {
            $model->slug ??= $model->generateUsername($model->name, 'slug', '-');
        });
    }

    /**
     * Retrieve the model for a bound value.
     *
     * @param  string|null  $field
     * @return \Illuminate\Database\Eloquent\Model|null
     */
    public function resolveRouteBinding($value, $field = null)
    {
        if ($value === 'authenticated') {
            return $this->where('user_id', auth('sanctum')->id())
                ->firstOrNew();
        }

        return $this->where('id', $value)
            ->orWhere('slug', $value)
            ->firstOrFail();
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function appointments(): HasManyThrough
    {
        return $this->hasManyThrough(Appointment::class, User::class, 'invitee_id');
    }
}