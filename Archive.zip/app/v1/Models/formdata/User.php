<?php

namespace V1\Models\formdata;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use App\Models\User as V1User;

class User extends V1User
{
}
