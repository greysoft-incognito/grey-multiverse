<?php

namespace V1\Http\Controllers\Admin\Learning;

use V1\Http\Controllers\Controller;

class CourseModuleController extends Controller
{
    //
}
