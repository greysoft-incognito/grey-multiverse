<?php

namespace V1\Http\Controllers\Learning;

use V1\Http\Controllers\Controller;

class AttendanceController extends Controller
{
    //
}
